package Utilities;

public class product {
	String p_name;
	String price;

}
