package Utilities;

public class data {
	String category;
	String search;
	String quantity;

}
