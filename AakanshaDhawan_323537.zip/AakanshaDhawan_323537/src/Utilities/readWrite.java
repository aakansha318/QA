package Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class readWrite {
	static ArrayList<data> al=new ArrayList<data>(); 
	  static data da;
	  
	static ArrayList<product> ap=new ArrayList<product>(); 
	static product p;
	
	  static String[][] sheet1;
	  String[] sheet;
	  static String[][] sheet2;
	public static String[][] readExcel() {
		  try {
				  File path=new File("D://assessment.xlsx");
				  FileInputStream f=new FileInputStream(path);
				  XSSFWorkbook wb=new XSSFWorkbook(f);
				  XSSFSheet sheet=wb.getSheet("Data");
				 // System.out.println(sheet+"1");
				  for(int i=1;i<=(sheet.getLastRowNum());i++)
				  {
					  //System.out.println("2");
						  da=new data();
						  XSSFRow r=sheet.getRow(i);
						  da.category=r.getCell(0).getStringCellValue();
						  da.search=r.getCell(1).getStringCellValue();
						  int a=(int) r.getCell(2).getNumericCellValue();
						  da.quantity=Integer.toString(a);
						  al.add(da);
						 
				  }
		  }catch (Exception e) {}
		  
		  sheet1=new String[al.size()][3];
		  for(int i=0;i<=al.size()-1;i++) {
			  System.out.println("3");
			  sheet1[i][0]=al.get(i).category;
			  sheet1[i][1]=al.get(i).search;
			  sheet1[i][2]=al.get(i).quantity;
			  System.out.println(sheet1[i][0]+sheet1[i][1]);
			  
		  }

		return sheet1;
	}
	
	
	
	public static String[][] read_sheet2() {
		try {
			  File path=new File("D://assessment.xlsx");
			  FileInputStream f=new FileInputStream(path);
			  XSSFWorkbook wb=new XSSFWorkbook(f);
			  XSSFSheet sheet=wb.getSheet("Verify");
			  for(int i=1;i<3;i++)
			  {
				  System.out.println("2");
					  p=new product();
					  XSSFRow r=sheet.getRow(i);
					  p.p_name=r.getCell(0).getStringCellValue();
					  p.price=r.getCell(1).getStringCellValue();
					  ap.add(p);
			  }
	  }catch (Exception e) {}
	  
	  sheet2=new String[ap.size()][2];
	  for(int i=0;i<ap.size();i++) {
		  System.out.println("2");
		  sheet2[i][0]=ap.get(i).p_name;
		  sheet2[i][1]=ap.get(i).price;
	  }
	return sheet2;
	}
	
	

}
