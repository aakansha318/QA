package TESTNG;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import BaseClasses.Home_Page;
import BaseClasses.Search_Results_Page;
import BaseClasses.Search_String;
import BaseClasses.Shopping_Cart;
import Utilities.readWrite;


public class Test1 {
	 WebDriver dr;
	 
	 Home_Page hp;
	 
	 Search_Results_Page srp;
	 
	 Search_String ss;
	 
	 Shopping_Cart sc;Shopping_Cart sc1;
	  
	 String[][] str1=readWrite.read_sheet2();
	  Logger log;
	  @BeforeClass
		public void launchbrowser() {
			System.setProperty("webdriver.chrome.driver","chromedriver_v75.exe");
			dr = new ChromeDriver();
	    	dr.get("http://examples.codecharge.com/Store/Default.php");	
	   }
	  
	  public void logUpd(String er,String ar,String status)
	  {
		  log=Logger.getLogger("devpinoyLogger");
		  log.info("============================================================"+"\n");
		  log.info("Excepted Result: "+er);
		  log.info("============================================================"+"\n");
		  log.info("Actual Result: "+ar);
		  log.info("============================================================"+"\n");
		  log.info("Test Result: "+status);
		  log.info("============================================================"+"\n");
	  }
	  
	  @Test(priority=2)
	  public void test1()
	  {
		  String status="Failed";
		  hp=new Home_Page(dr);
		  String er="Online Bookstore";
		  String ar=hp.verifyTitle();
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);
	  }
	  
	  @Test(priority=3)
	  public void test2()
	  {
		  String status="Failed";
		  String er="Search Products";
		  String ar=hp.verifyText();
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);
	  }
	  
	  @Test(dataProvider = "data",priority=4)
	  public void  test3(String category,String search,String quantity) {
		  System.out.println("here");
		  String status="Failed";
		  hp.select_menu(category, search);
		  srp=new Search_Results_Page(dr);
		  String er="SearchResults";
		  String ar=srp.verify_title();
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);
		  srp.Click_product();		
		  
		  ss=new Search_String(dr);
		  
		  ss.clear_input();
		  ss.enter_input(quantity);
		  ss.click_add();
		  
		  sc = new Shopping_Cart(dr);
		  
		  sc.click_home();
		 // sc.click_cart();
	  }
	  
	  @Test(priority=5)
	  public void  tst() {
		  sc.click_cart();
	  }
	 
	  
	  @Test(dataProvider = "data1",priority=6)
	  public void  test4(String product) {
		  String status="Failed";	  
		  String ar=sc.get_text1();
		  String er=product;
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);		  
	  }
	  
	  @Test(dataProvider = "data2",priority=7)
	  public void  test5(String product) {
		  String status="Failed";
		  
		  String ar=sc.get_text2();
		  String er=product;
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);		  
	  }
	  
	  @Test(dataProvider = "data3",priority=8)
	  public void  test6(String price) {
		  String status="Failed";
		  String ar=sc.get_text1();
		  String er=price;
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);		  
	  }
	  
	  @Test(dataProvider = "data4",priority=9)
	  public void  test7(String price) {
		  String status="Failed";
		  String ar=sc.get_text1();
		  String er=price;
		  Assert.assertEquals(ar,er);
		  status="Passed";
		  logUpd(er,ar,status);		  
	  }
	  	  
	  @DataProvider
	  public String[][] data() {
		  String[][] str=readWrite.readExcel();
	    return str;
	  }
	  
	  @DataProvider
	  public String data1() {
		  //String[][] str=readWrite.readExcel();
	    return str1[0][0];
	  }
	  

	  @DataProvider
	  public String data2() {
		  //String[][] str=readWrite.readExcel();
	    return str1[1][0];
	  }

	  @DataProvider
	  public String data3() {
		  
		  //String[][] str=readWrite.readExcel();
	    return str1[0][1];
	  }

	  @DataProvider
	  public String data4() {
		  //String[][] str=readWrite.readExcel();
	    return str1[1][1];
	  }
	  
	  
}
