package BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Home_Page {
	WebDriver dr;
	Select allmenu;
	
	@FindBy(name="category_id")
	WebElement drpDwn;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[1]/tbody/tr/th")
	WebElement searchProduct;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[2]/td/input")
	WebElement input;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td[1]/form/table[2]/tbody/tr[3]/td/input")
	WebElement button;
	
	public Home_Page(WebDriver dr) {
		this.dr =dr;
		PageFactory.initElements(dr, this);	
	}
	
	public String verifyTitle() {
		return dr.getTitle();
	}
	
	public String verifyText() {
		return searchProduct.getText();
	}
	
	public void select_menu(String category,String searchString) {
		allmenu= new Select(drpDwn);
		allmenu.selectByVisibleText(category);
		input.sendKeys(searchString);
		button.click();
	}

}
