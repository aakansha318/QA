package BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Search_Results_Page {

	WebDriver dr;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td/table[2]/tbody/tr[1]/td[2]/b/a")
	WebElement path;

	public Search_Results_Page(WebDriver dr) {
		this.dr =dr;
		PageFactory.initElements(dr, this);	
	}
	
	public String verify_title() {
		return dr.getTitle();
	}
	
	public void Click_product() {
		path.click();
	}
}
