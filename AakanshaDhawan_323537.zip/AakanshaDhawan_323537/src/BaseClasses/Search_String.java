package BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Search_String {
	
	WebDriver dr;
	
	@FindBy(xpath="/html/body/table[5]/tbody/tr/td/form/form/p[1]/input")
	WebElement path;

	@FindBy(xpath="/html/body/table[5]/tbody/tr/td/form/form/p[2]/input[1]")
	WebElement add_button;
	
	public Search_String(WebDriver dr) {
		this.dr =dr;
		PageFactory.initElements(dr, this);	
	}

	public String verify_title() {
		return dr.getTitle();
		}
	
	public void clear_input() {
		path.clear();
	}
	
	public void enter_input(String a) {
		path.sendKeys(a);
	}
	
	public void click_add() {
		add_button.click();
	}
	
	}
