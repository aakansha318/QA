package BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Shopping_Cart {
	
	WebDriver dr;
	@FindBy(xpath="/html/body/table[2]/tbody/tr/td/a[1]")
	WebElement  home1;
	
	
	@FindBy(xpath="/html/body/table[2]/tbody/tr/td/a[3]")
	WebElement cart;
	
	@FindBy(xpath="//tr[@class='Caption'][1]/following::td[1]")
	WebElement text1;
	
	@FindBy(xpath="//tr[@class='Caption'][1]/following::td[6]")
	WebElement text2;
	
	@FindBy(xpath="//tr[@class='Caption'][1]/following::td[4]")
	WebElement total1;
	
	@FindBy(xpath="//tr[@class='Caption'][1]/following::td[9]")
	WebElement total2;
	
	public void click_home() {
		home1.click();
	}
	
	public void click_cart() {
		cart.click();
	}
	
	public Shopping_Cart(WebDriver dr) {
		this.dr =dr;
		PageFactory.initElements(dr, this);	
	}
	
	public String get_text1() {
		return text1.getText();
	}
	
	public String get_text2() {
		return text2.getText();
	}
	
	public String get_total1() {
		return total1.getText();
	}
	
	public String get_total2() {
		return total2.getText();
	}

}
